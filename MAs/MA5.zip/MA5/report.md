# Mandatory Assignment 5

We have images of the potentiometer and the rest are videos in the zip files.

![Reading Voltage Of Ardiuno 5V out](Power.jpg)

![Reading voltage in the middle of potentiometer](Voltage_middle_potentiometer.jpg)

![Reading Current in the middle of potentiometer](Current_Potentiometer_meter.jpg)

![Where Readings where took on the potentiometer](Where_Readings_Where_Took_On_The_Potentiometer.jpg)

![Potentiometer](Potentiometer_real.jpg)